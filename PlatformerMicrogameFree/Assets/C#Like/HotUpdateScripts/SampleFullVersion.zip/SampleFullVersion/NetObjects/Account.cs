//It's automatic generate by Account.ridl.
//You can custom this class, such as override the virtual function in class Account_Base, but DON'T modify 'Account_Base.cs'.
using System;
using System.Collections.Generic;
using UnityEngine;

namespace CSharpLike
{
	public class Account : Account_Base
	{
		public enum AccountType
		{
			BuildIn,//Build-in account
			ThirdParty_Test,//Sample for test third party account.
							//Login flow :
							//Client got uid and token from third party SDK. 
							//-> send to our server.
							//-> our server confirm that uid and token from third party server by HTTP(s).
							//-> login success/fail
		}
		#region Event for property value changed
		public override void OnChanged()
		{
			//Add your code here, or delete this function if you don't need it.
			SampleCSharpLikeHotUpdate.strTips = "Account:" + ToString();
		}
		public override void OnUidChanged()
		{
			//Add your code here, or delete this function if you don't need it.
		}
		public override void OnNameChanged()
		{
			//Add your code here, or delete this function if you don't need it.
		}
		public override void OnNicknameChanged()
		{
			//Add your code here, or delete this function if you don't need it.
		}
		public override void OnMoneyChanged()
		{
			//Add your code here, or delete this function if you don't need it.
		}
		public override void OnScoreChanged()
		{
			//Add your code here, or delete this function if you don't need it.
		}
		public override void OnLastLoginTimeChanged()
		{
			//Add your code here, or delete this function if you don't need it.
		}
		public override void OnDeleted()
		{
			//Add your code here, or delete this function if you don't need it.
		}
		#endregion //Event for property value changed
		#region Event for sub system had callback object or delete
		public override void OnCallbackObjectItems(List<Item> data)
		{
			//We print the item that just changed, you may do some update to the UI
			foreach (Item item in data)
				Debug.Log("OnCallbackObjectItems:changed item:" + item.ToString());
			//We print all item count
			Debug.Log("OnCallbackObjectItems:now all item count = " + items.Count);
		}
		public override void OnCallbackDeleteItems(List<Item> data)
		{
			//We print the item that just deleted, you may do some update to the UI
			foreach (Item item in data)
				Debug.Log("OnCallbackDeleteItems:delete item:" + item.ToString());
			//We print all item count
			Debug.Log("OnCallbackDeleteItems:now all item count = " + items.Count);
		}
		public override void OnCallbackObjectMails(List<Mail> data)
		{
			//We print the item that just changed, you may do some update to the UI
			foreach (Mail mail in data)
				Debug.Log("OnCallbackObjectMails:changed mail:" + mail.ToString());
			//We print all mail count
			Debug.Log("OnCallbackObjectMails:now all mail count = " + mails.Count);
		}
		public override void OnCallbackDeleteMails(List<Mail> data)
		{
			//We print the item that just deleted, you may do some update to the UI
			foreach (Mail mail in data)
				Debug.Log("OnCallbackObjectMails:deleted mail:" + mail.ToString());
			//We print all mail count
			Debug.Log("OnCallbackObjectMails:now all mail count = " + mails.Count);
		}
		public override void OnCallbackObjectSignIn()
		{
			Debug.Log("OnCallbackObjectSignIn:" + signIn.ToString());
		}
		public override void OnCallbackDeleteSignIn()
		{
			Debug.Log("OnCallbackDeleteSignIn:" + signIn.ToString());
		}
		#endregion //Event for sub system had callback object or delete
	}
}
