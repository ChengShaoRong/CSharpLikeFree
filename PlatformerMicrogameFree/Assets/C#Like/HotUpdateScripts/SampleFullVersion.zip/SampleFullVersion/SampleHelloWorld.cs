/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using UnityEngine;
using System;
using System.Collections;
using UnityEngine.Networking;
using System.IO;

namespace CSharpLike
{
    /// <summary>
    /// Example for HelloWorld.
    /// Show the most simple usage of the Unity periodic functions.(support all MonoBehaviour event,but we just show the some of them.)
    /// And the usage of coroutine
    /// </summary>
    public class SampleHelloWorld : LikeBehaviour
    {
        void Awake()
        {
            gameObject.name = "I'm HotUpdateBehaviour";
            Debug.Log("Awake:same with MonoBehaviour");
        }
        void OnEnable()
        {
            Debug.Log("OnEnable:same with MonoBehaviour");
        }
        IEnumerator Start()
        {
            Debug.Log("Start:same with MonoBehaviour");
            Debug.LogError("Start:before WaitForSeconds:" + DateTime.Now);
            yield return new WaitForSeconds(2f);
            Debug.LogError("Start:after WaitForSeconds:" + DateTime.Now);
            /*only support 'Coroutine StartCoroutine(string methodName, params object[] vars)'.
            not support 'Coroutine StartCoroutine(IEnumerator routine)'.
            We call a sub coroutine with 3 params for example.*/
            yield return StartCoroutine("SubCoroutine", "test string", 123, -1f);//example for call a sub coroutine
            Debug.LogError("Start:after SubCoroutine:" + DateTime.Now);
            ////usage of stop coroutine:same with MonoBehaviour
            //StopCoroutine("SubCoroutine");
            //StopAllCoroutines();
        }
        //the coroutine call by Start() 
        IEnumerator SubCoroutine(string strValue, int iValue, float fValue)
        {
            Debug.LogError("SubCoroutine(" + strValue + "," + iValue + "," + fValue + ")");
            yield return new WaitForSeconds(2f);
            if (fValue > 0f)
                yield break;
            else
            {
                //test Nullable type '?' coalescing operator '?.' and '??'
                System.Random r = null;//new System.Random();
                int? i = r?.Next(1000);
                Debug.LogError("SubCoroutine:i=" + (i ?? iValue));
            }
            yield return new WaitForEndOfFrame();
            Debug.LogError("SubCoroutine:end:" + DateTime.Now);
        }
        void FixedUpdate()
        {
            Debug.Log("FixedUpdate:same with MonoBehaviour");
        }
        float angle = 0f;
        void Update()
        {
            //Debug.Log("LateUpdate:same with MonoBehaviour");
            angle += Time.deltaTime * 50f;
            transform.localEulerAngles = new Vector3(0f, angle, 0f);
        }
        void LateUpdate()
        {
            Debug.Log("LateUpdate:same with MonoBehaviour");
        }
        void OnGUI()
        {
            //Debug.Log("OnGUI:same with MonoBehaviour");
            if (GUI.Button(new Rect(0, 0, 64, 64), "Back"))
            {
                HotUpdateManager.Show("Assets/C#Like/Sample/SampleCSharpLikeHotUpdate.prefab");//back to SampleCSharpLikeHotUpdate
                HotUpdateManager.Hide("Assets/C#Like/Sample/SampleHelloWorld.prefab");//close self
            }
        }
        void OnDisable()
        {
            Debug.Log("OnDisable:same with MonoBehaviour");
        }
        void OnDestroy()
        {
            Debug.Log("OnDestroy:same with MonoBehaviour");
        }
    }
}