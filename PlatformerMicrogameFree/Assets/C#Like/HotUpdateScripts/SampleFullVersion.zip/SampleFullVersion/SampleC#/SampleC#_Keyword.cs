/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using UnityEngine;//test using command
using System;
using Random = UnityEngine.Random;//test using alias
using System.Text;
using System.IO;

namespace CSharpLike
{
    /// <summary>
    /// Example test C# function in hot update script.
    /// </summary>
    public partial class SampleCSharp : LikeBehaviour
    {
        /// <summary>
        /// test not classify keyword 
        /// </summary>
        void TestKeyword()
        {
            Debug.LogError("Test Keyword:");
            //test keyword 'sizeof'
            //'sizeof(int/uint/long/ulong/short/ushort/char/float/double/decimal/bool/sbyte/byte)' no need allow unsafe code
            Debug.Log("sizeof(int) = " + sizeof(int));//output sizeof(int) = 4

            //The define symbol open by the check box of Menu/Edit/Project Setting/Player/Other Settings/Allow 'unsafe' Code
            //The define symbol close by the remove it from Menu/Edit/Project Settings/Player/Other Settings/Scripting Define Symbols
#if _CSHARP_LIKE_ALLOW_UNSAFE_CODE_
            //test keyword 'unsafe'
            unsafe
            {
                Debug.Log("sizeof(Vector2) = " + sizeof(Vector2));//output sizeof(Vector2) = 8
                Debug.Log("sizeof(Rect) = " + sizeof(Rect));//output sizeof(Rect) = 16
            }
            TestUnSafe();
#endif
            //test keyword 'typeof'
            var tType = typeof(SampleCSharp);//don't define as 'Type tType = typeof(SampleCSharp);', must use 'var'
            Debug.Log("typeof(SampleCSharp) = " + tType);//output CSharpLike.SampleCSharp
            var thisType = GetType();//don't define as 'Type thisType = GetType();', must use 'var'
            Debug.Log("thisType = " + thisType);//output CSharpLike.SampleCSharp
            Debug.Log("thisType == tType:" + (thisType == tType));//output True
            if (this.GetType() == typeof(SampleCSharp))
                Debug.Log("GetType() == typeof(SampleCSharp)");
            else
                Debug.Log("GetType() != typeof(SampleCSharp)");

            //build-in data type,
            //Int32/UInt32/Int64/UInt64/Int16/UInt16/Char/Single/Double/Decimal/Boolean/SByte/Byte/String.
            //equal
            //int/uint/long/ulong/short/ushort/char/float/double/decimal/bool/sbyte/byte/string.
            Int32 i = 123;//equal to 'int i = 123;'
            Debug.Log("test Int32 i = " + i);//output 123

            //test keyword "$", syntactic sugar for string.Format
            string str = $"abc{i}sdf{"xyz"}";//same with 'string str = string.Format("abc{0}sdf{1}", i, "xyz");'
            Debug.Log("test keyword '$' with '\"', $\"abc{i}sdf{\"xyz\"} = " + str);//output abc123sdfxyz

            //test keyword "@"
            str = @"{""a"":1,
                ""b"":""abc""}";//same with 'str = "{\"a\":1,\n                \"b\":\"abc\"}";'
            Debug.Log("test keyword '@' with '\"', str = " + str);

            //test keyword #pragma #warning #error
#pragma warning disable CS0168
            int j;//It'll get warning(CS0168) in editor if don't set '#pragma warning disable CS0168'
#pragma warning restore CS0168
#warning "This's a test #warning."
#if UNITY_4_0
#error "This's a test #error."
#endif//UNITY_4_0
        }

        //The define symbol open by the check box of Menu/Edit/Project Setting/Player/Other Settings/Allow 'unsafe' Code
        //The define symbol close by the remove it from Menu/Edit/Project Settings/Player/Other Settings/Scripting Define Symbols
#if _CSHARP_LIKE_ALLOW_UNSAFE_CODE_
        //test keyword 'unsafe' in function
        unsafe void TestUnSafe()
        {
            Debug.Log("sizeof(Vector3) = " + sizeof(Vector3));//output sizeof(Vector3) = 12
        }
#endif
    }
}