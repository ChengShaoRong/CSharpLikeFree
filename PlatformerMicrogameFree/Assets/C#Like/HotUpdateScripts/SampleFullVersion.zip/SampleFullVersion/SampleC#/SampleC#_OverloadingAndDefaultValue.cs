/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using UnityEngine;

namespace CSharpLike
{
    /// <summary>
    /// Example test C# function in hot update script.
    /// </summary>
    public partial class SampleCSharp : LikeBehaviour
    {
        /// <summary>
        /// test function overloading and function param default value
        /// </summary>
        void TestOverloadingAndDefaultValue()
        {
            Debug.LogError("Test OverloadingAndDefaultValue:");
            //test function overloading, same as native C#
            Debug.Log("TestOverloading:" + TestOverloading());//output Sunday
            Debug.Log("TestOverloading:" + TestOverloading(123));//output Monday123
            Debug.Log("TestOverloading:" + TestOverloading("abc"));//output Tuesdayabc
            Debug.Log("TestOverloading:" + TestOverloading("cba", 321));//output Wednesdaycba321

            //test function param default value, same as native C#
            TestDefaultParam();//output TestDefaultParam:i=1,j=(0.0,0.0),k=str
            TestDefaultParam(100);//output TestDefaultParam:i=100,j=(0.0,0.0),k=str
            TestDefaultParam(110, new Vector2(1, 2));//output TestDefaultParam:i=110,j=(1.0,2.0),k=str
            TestDefaultParam(120, Vector2.one, "string2222");//output TestDefaultParam:i=120,j=(1.0,1.0),k=string2222
        }
        string TestOverloading()
        {
            return "Sunday";
        }
        string TestOverloading(int i)
        {
            return "Monday" + i;
        }
        string TestOverloading(string str)
        {
            return "Tuesday" + str;
        }
        string TestOverloading(string str, int i)
        {
            return "Wednesday" + str + i;
        }
        void TestDefaultParam(int i = 1, Vector2 j = new Vector2(), in string k = "str")
        {
            Debug.Log("TestDefaultParam:i=" + i + ",j=" + j + ",k=" + k);
        }
    }
}