/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using UnityEngine;

namespace CSharpLike
{
    /// <summary>
    /// Example test C# function in hot update script.
    /// </summary>
    public partial class SampleCSharp : LikeBehaviour
    {
        void TestGetSetAccessor()
        {
            Debug.LogError("Test TestGetSetAccessor:");
            //test auto implement get set accessor
            Debug.Log("before set value testGetSetAutoImp = " + testGetSetAutoImp);//output False
            testGetSetAutoImp = true;
            Debug.Log("after set value: testGetSetAutoImp = " + testGetSetAutoImp);//output True

            //test custom get set accessor
            Debug.Log("before set value testGetSet = " + testGetSetCustom);//output 101
            testGetSetCustom = 1;
            Debug.Log("after set value: testGetSet = " + testGetSetCustom);//output 1

            //test static get set
            Debug.Log("before set value testStaticGetSet = " + testStaticGetSet);//output 'default string'
            testStaticGetSet = "I like C#";
            Debug.Log("after set value: testStaticGetSet = " + testStaticGetSet);//output 'I like C#'
        }

        public bool testGetSetAutoImp { get;set; }

        int mTestGetSetCustom = 101;
        public int testGetSetCustom
        {
            get
            {
                return mTestGetSetCustom;
            }
            private set
            {
                mTestGetSetCustom = value;
            }
        }
        static string mTestStaticGetSet = "default string";
        public static string testStaticGetSet
        {
            get
            {
                return mTestStaticGetSet;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                    mTestStaticGetSet = value;
                else
                {
                    Debug.Log("set value null or empty,reset to default string 'default string'");
                    mTestStaticGetSet = "default string";
                }
            }
        }
    }
}