English:
They are 6 examples in this folder:
	1 ExampleHelloWorld.cs Introduces the most concise and commonly used of periodic functions of MonoBehaviour and the usage of coroutine.
	2 ExampleInteractivePrefabData.cs Introduces how C#Like interact data with prefab.
	3 ExampleC# folder. Introduces all the C# functions that C#Like supported and show how to use them.
	4 AircraftBattle folder. An aircraft battle game, the interface show the player's HP,money and score.Player can control the aircraft and automatic shoot the enemy, player will get scores and moneys when enemy crash down. They are 5 classes include Aircraft,BattleField,Bullet,Enemy and Money. All the data store in prefab as JSON string. All the pictures in this game were draw on paper by my children.
	5 SampleSocket.cs Sample for how to use Socket/WebSocket.
	6 SampleLogin.cs Sample for using 'SampleSocket.cs' to login game server and interact with game server. NetObjects folder is the transfer object between client and server. Game server is KissServerFramework(I had uploaded to https://github.com/ChengShaoRong/KissServerFramework).

Chinese:
本目录下有6个例子:
	1 ExampleHelloWorld.cs 介绍了最精简的常用MonoBehaviour生命周期函数,及使用协程的例子.
	2 ExampleInteractivePrefabData.cs 介绍了C#Like如何与预制体之间交互数据.
	3 ExampleC#目录 是介绍了C#Like所有支持的C#功能,里面均举例子详细如何使用它们.
	4 AircraftBattle目录 是一个打飞机小游戏,界面上显示血量/金钱/分数,玩家操控飞机,子弹均自动发射,击毁敌机获得分数,敌机毁掉后会掉落金币,玩家可以靠近金币去捡,当飞机血量为0则游戏结束.里面总共5个类(飞机类,战场类,子弹类,敌机类,金钱类),数据均以JSON方式设置在预制体内.游戏界面的底图/飞机/子弹/金钱均为我的宝贝孩子自由发挥手绘在纸上后拍照的.
	5 SampleSocket.cs 是使用Socket/WebSocket连接的示例
	6 SampleLogin.cs 是使用SampleSocket.cs作为连接的登录游戏服务器且交互的例子. NetObjects目录为传输对象,游戏服务器为KissServerFramework(我已上传到 https://github.com/ChengShaoRong/KissServerFramework)