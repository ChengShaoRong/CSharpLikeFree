﻿using CSharpLike.Internal;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace Microgame
{
    public static partial class Simulation
    {
        static Dictionary<object, Event> events = new Dictionary<object, Event>();
        /// <summary>
        /// An event is something that happens at a point in time in a simulation.
        /// The Precondition method is used to check if the event should be executed,
        /// as conditions may have changed in the simulation since the event was 
        /// originally scheduled.
        /// </summary>
        /// <typeparam name="Event"></typeparam>
        public class Event : IComparable<Event>
        {
            internal float tick;
            internal object obj;
            private Type type;
            internal SInstance objS;
            internal string fullName;
            public Event(Type type)
            {
                this.type = type;
                obj = type.Assembly.CreateInstance(type.FullName);
                events[obj] = this;
                fullName = type.FullName;
            }
            public Event(SType type)
            {
                objS = type.New().value as SInstance;
                events[objS] = this;
                fullName = type.FullName;
            }

            public int CompareTo(Event other)
            {
                return tick.CompareTo(other.tick);
            }

            public void Execute()
            {
                if (Exist("Execute"))
                {
                    MemberCall("Execute");
                    if (onExecutes.TryGetValue(fullName, out Action<object> _action))
                    {
                        if (obj != null)
                            _action?.Invoke(obj);
                        else
                            _action?.Invoke(objS);
                    }
                }
            }

            bool Exist(string funcName)
            {
                if (objS != null)
                {
                    return objS.Exist(funcName);
                }
                else if (obj != null)
                {
                    return type.GetMethod(funcName) != null;
                }
                return false;
            }
            object MemberCall(string funcName)
            {
                if (objS != null)
                {
                    return objS.MemberCall(funcName);
                }
                else if (obj != null)
                {
                    MethodInfo mi = type.GetMethod(funcName);
                    if (mi != null)
                        return mi.Invoke(obj, null);
                }
                return null;
            }

            public bool Precondition()
            {
                if (Exist("Precondition"))
                    return (bool)MemberCall("Precondition");
                return true;
            }

            internal void ExecuteEvent()
            {
                if (Precondition())
                    Execute();
            }

            /// <summary>
            /// This method is generally used to set references to null when required.
            /// It is automatically called by the Simulation when an event has completed.
            /// </summary>
            internal void Cleanup()
            {
                if (Exist("Cleanup"))
                    MemberCall("Cleanup");
            }
        }
        static Dictionary<string, Action<object>> onExecutes = new Dictionary<string, Action<object>>();
        public static void OnExecute(Type type, Action<object> action)
        {
            if (onExecutes.TryGetValue(type.FullName, out Action<object> _action))
            {
                _action += action;
            }
            else
            {
                onExecutes[type.FullName] = action;
            }
        }
        public static void OnExecute(SType type, Action<object> action)
        {
            OnExecute(type.FullName, action);
        }
        public static void OnExecute(string fullName, Action<object> action)
        {
            if (onExecutes.TryGetValue(fullName, out Action<object> _action))
            {
                _action += action;
            }
            else
            {
                onExecutes[fullName] = action;
            }
        }
    }
}