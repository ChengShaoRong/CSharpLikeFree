using CSharpLike.Internal;
using System;
using System.Collections.Generic;
using UnityEngine;


namespace Microgame
{
    /// <summary>
    /// The Simulation class implements the discrete event simulator pattern.
    /// Events are pooled, with a default capacity of 4 instances.
    /// </summary>
    public static partial class Simulation
    {

        static HeapQueue<Event> eventQueue = new HeapQueue<Event>();
        static Dictionary<string, Stack<Event>> eventPools = new Dictionary<string, Stack<Event>>();

        /// <summary>
        /// Create a new event of type T and return it, but do not schedule it.
        /// </summary>
        static public Event New(Type type)
        {
            Stack<Event> pool;
            if (!eventPools.TryGetValue(type.FullName, out pool))
            {
                pool = new Stack<Event>(4);
                var e = new Event(type);
                pool.Push(e);
                eventPools[type.FullName] = pool;
            }
            if (pool.Count > 0)
                return pool.Pop();
            else
                return new Event(type);
        }
        static public Event New(SType type)
        {
            Stack<Event> pool;
            if (!eventPools.TryGetValue(type.FullName, out pool))
            {
                pool = new Stack<Event>(4);
                var e = new Event(type);
                pool.Push(e);
                eventPools[type.FullName] = pool;
            }
            if (pool.Count > 0)
                return pool.Pop();
            else
                return new Event(type);
        }

        /// <summary>
        /// Clear all pending events and reset the tick to 0.
        /// </summary>
        public static void Clear()
        {
            eventQueue.Clear();
        }

        static public object Schedule(Type type, float tick = 0f)
        {
            //Debug.LogError($"Schedule Type {type.FullName}");
            Event ev = New(type);
            ev.tick = Time.time + tick;
            eventQueue.Push(ev);
            return ev.obj;
        }

        static public object Schedule(SType type, float tick = 0f)
        {
            //Debug.LogError($"Schedule SType {type.FullName}");
            Event ev = New(type);
            ev.tick = Time.time + tick;
            eventQueue.Push(ev);
            return ev.objS;
        }

        /// <summary>
        /// Reschedule an existing event for a future tick, and return it.
        /// </summary>
        /// <returns>The event.</returns>
        /// <param name="tick">Tick.</param>
        static public object Reschedule(object obj, float tick = 0)
        {
            if (events.TryGetValue(obj, out Event ev))
            {
                ev.tick = Time.time + tick;
                eventQueue.Push(ev);
            }
            return obj;
        }

        /// <summary>
        /// Tick the simulation. Returns the count of remaining events.
        /// If remaining events is zero, the simulation is finished unless events are
        /// injected from an external system via a Schedule() call.
        /// </summary>
        /// <returns></returns>
        static public int Tick()
        {
            var time = Time.time;
            var executedEventCount = 0;
            while (eventQueue.Count > 0 && eventQueue.Peek().tick <= time)
            {
                var ev = eventQueue.Pop();
                var tick = ev.tick;
                ev.ExecuteEvent();
                if (ev.tick > tick)
                {
                    //event was rescheduled, so do not return it to the pool.
                }
                else
                {
                    // Debug.Log($"<color=green>{ev.tick} {ev.GetType().Name}</color>");
                    ev.Cleanup();
                    try
                    {
                        eventPools[ev.fullName].Push(ev);
                    }
                    catch (KeyNotFoundException)
                    {
                        //This really should never happen inside a production build.
                        Debug.LogError($"No Pool for: {ev.GetType()}");
                    }
                }
                executedEventCount++;
            }
            return eventQueue.Count;
        }
    }
}


