/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using UnityEngine;

namespace CSharpLike
{
    /// <summary>
    /// Example test C# function in hot update script.
    /// </summary>
    public partial class SampleCSharp : LikeBehaviour
    {
        /// <summary>
        /// test math expression:
        /// + - * / % += -= *= /= %= > >= < <= != == && || ! ++ -- is as  & | ~ ^ &= |= ^= << >> <<= >>= ? ?? ?. ?:
        /// </summary>
        void TestMathExpression()
        {
            Debug.LogError("Test MathExpression:");
            int i = 1;
            int j = 2;
            int k = 100;
            //test: + - * / %
            Debug.Log("i = 1, j = 2, test i + j = " + (i + j));//output 3
            Debug.Log("i = 1, j = 2, test i - j = " + (i - j));//output -1
            Debug.Log("i = 1, j = 2, test i * j = " + (i * j));//output 2
            Debug.Log("i = 1, j = 2, test i / j = " + (i / j));//output 0
            Debug.Log("i = 1, j = 2, test i % j = " + (i % j));//output 1

            //test: += -= *= /= %=
            k += j;
            Debug.Log("j = 2, k = 100, test k += j then k = " + k);//output 102
            k = 100;
            k -= j;
            Debug.Log("j = 2, k = 100, test k -= j then k = " + k);//output 98
            k = 100;
            k *= j;
            Debug.Log("j = 2, k = 100, test k *= j then k = " + k);//output 200
            k = 100;
            k /= j;
            Debug.Log("j = 2, k = 100, test k /= j then k = " + k);//output 50
            k = 100;
            k %= j;
            Debug.Log("j = 2, k = 100, k %= j then k = " + k);//output 0

            //test: > >= < <= != ==
            Debug.Log("i = 1, j = 2, test (i < j) = " + (i < j));//output True
            Debug.Log("i = 1, j = 2, test (i <= j) = " + (i <= j));//output True
            Debug.Log("i = 1, j = 2, test (i == j) = " + (i == j));//output False
            Debug.Log("i = 1, j = 2, test (i != j) = " + (i != j));//output True
            Debug.Log("i = 1, j = 2, test (i > j) = " + (i > j));//output False
            Debug.Log("i = 1, j = 2, test (i >= j) = " + (i >= j));//output False

            //test: && || !
            bool b1 = true;
            bool b2 = false;
            Debug.Log("b1 = true, b2 = false, test (b1 && b2) = " + (b1 && b2));//output False
            Debug.Log("b1 = true, b2 = false, test (b1 || b2) = " + (b1 || b2));//output True
            Debug.Log("b1 = true, test (!b1) = " + (!b1));//output False

            //test: ++ --(include prefix and suffix)
            k = 100;
            Debug.Log("k = 100, test (k++) = " + (k++));//output 100
            Debug.Log("finally k = " + k);//output 101
            k = 100;
            Debug.Log("k = 100, test (++k) = " + (++k));//output 101
            Debug.Log("finally k = " + k);//output 101
            k = 100;
            Debug.Log("k = 100, test (k--) = " + (k--));//output 100
            Debug.Log("finally k = " + k);//output 99
            k = 100;
            Debug.Log("k = 100, test (--k) = " + (--k));//output 99
            Debug.Log("finally k = " + k);//output 99
            // We are not support '++' '--' with index get/set '[]',
            // such as List or Dictionary or JSONData.
            //// List<int> lists = new List<int>();
            //// lists.Add(1);
            //// lists[0]++;//compiler error,suggest use 'lists[0] += 1;' instead
            //// ++lists[0];//runtime error,suggest use 'lists[0] += 1;' instead


            //test convert: 'is' 'as'
            object o = i;
            Debug.Log("int i = 1,object o = i, test (o is int) = " + (o is string));//output False
            Debug.Log("int i = 1,object o = i, test (o as string) = " + (o as string));//output null

            //test ternary expression: '?:'
            Debug.Log("i = 1, j = 2, test ((i < j) ? i : j) = " + ((i < j) ? i : j));//output 1
            //test nullable types '?' and coalescing operator '?.' '??'
            Vector2? v1 = null;//nullable types '?'
            Debug.Log("Vector2? v1 = null, test v1.HasValue = " + v1.HasValue);//output False
            //Debug.Log("Vector2? v1 = null, test v1.Value = " + v1.Value);//error
            Debug.Log("Vector2? v1 = null, test v1.GetValueOrDefault = " + v1.GetValueOrDefault());//output (0.0,0.0)
            Debug.Log("Vector2? v1 = null, test v1 = " + v1);//output null
            v1 = Vector2.one;
            Debug.Log("Vector2? v1 = Vector2.one, test v1.HasValue = " + v1.HasValue);//output True
            Debug.Log("Vector2? v1 = Vector2.one, test v1.Value = " + v1.Value);//output (1.0,1.0)
            Debug.Log("Vector2? v1 = Vector2.one, test v1.GetValueOrDefault = " + v1.GetValueOrDefault());//output (0.0,0.0)
            Debug.Log("Vector2? v1 = Vector2.one, test v1 = " + v1);//output (1.0,1.0)
            v1 = null;
            Vector2 v2 = v1.HasValue ? v1.Value : v1.GetValueOrDefault();//you should not force cast like 'Vector2 v2 = (Vector2)v1;'
            Debug.Log("Vector2 v2 = v1.HasValue ? v1.Value : v1.GetValueOrDefault(), test v2 = " + v2);//output (0.0,0.0)
            v1 = Vector2.one;
            v2 = v1 ?? Vector2.zero;//coalescing operator '??'
            Debug.Log("Vector2 v2 = v1 ?? Vector2.zero, test v2 = " + v2);//output (1.0,1.0)
            System.Random r = null;
            int? iNull = r?.Next(1000);
            Debug.Log("int? iNull = r?.Next(1000), test iNull = " + iNull);//output null
            r = new System.Random();
            iNull = r?.Next(1000); //coalescing operator '?.'
            Debug.Log("int? iNull = r?.Next(1000), test iNull = " + iNull);//output [0,1000)
            iNull += i;
            Debug.Log("i = 1, iNull += i, test iNull = " + iNull);//output [1,1001)

            //test bit operation: << <<= >> >>=
            Debug.Log("i = 1, j = 2, test i << j = " + (i << j));//output 4
            Debug.Log("i = 1, j = 2, test i >> j = " + (i >> j));//output 0
            k = 100;
            k <<= j;
            Debug.Log("j = 2, k = 100, test k <<= j then k = " + k);//output 400
            k = 100;
            k >>= j;
            Debug.Log("j = 2, k = 100, test k >>= j then k = " + k);//output 25

            //test bit operation: & | ^ &= |= ^= ~
            Debug.Log("i = 1, j = 2, test i & j = " + (i & j));//output 0
            Debug.Log("i = 1, j = 2, test i | j = " + (i | j));//output 3
            Debug.Log("i = 1, j = 2, test i ^ j = " + (i ^ j));//output 3
            k = 100;
            k &= j;
            Debug.Log("j = 2, k = 100, test k &= j then k = " + k);//output 0
            k = 100;
            k |= j;
            Debug.Log("j = 2, k = 100, test k |= j then k = " + k);//output 102
            k = 100;
            k ^= j;
            Debug.Log("j = 2, k = 100, test k ^= j then k = " + k);//output 102
            Debug.Log("i = 1, test (~i) = " + (~i));//output -2
        }

    }
}