/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using UnityEngine;
using System;

namespace CSharpLike
{
    /// <summary>
    /// Example test C# function in hot update script.
    /// </summary>
    public partial class SampleCSharp : LikeBehaviour
    {
        void TestException()
        {
            Debug.LogError("Test Exception:");
            //test the try {} catch (Exception e)  {} finally {}
            try
            {
                Debug.Log("test try step 1");
                CrashHere();
                Debug.Log("test try step 2");//won't reach here
            }
            catch (Exception e)
            {
                //output in Console
                //Error msg:Non-static method requires a target. Stack info:
                //class:SampleCSharp function:CrashHere() file:\ExampleC#_Exception.cs line:74
                //class:SampleCSharp function:TestException() file:\ExampleC#_Exception.cs line:21
                //class:SampleCSharp function:Start() file:\ExampleC#.cs line:28
                Debug.LogError("catch error:" + e);
            }
            finally
            {
                Debug.Log("test try step 3");
            }

            //test the try {} catch {}
            try
            {
                Debug.Log("test try step 4");
                int x = 100;
                int y = 1 / (x - 100);//Divide 0,will be error here
                Debug.Log("test try step 5");//won't reach here
            }
            catch//stype of without the (Exception e)
            {
                Debug.LogError("catch error");
            }

            try
            {
                //test the try {} finally {},this style won't catch error,that exception will continue throw until be catch
                try
                {
                    Debug.Log("test try step 6");
                    ThrowExcept();
                    Debug.Log("test try step 7");//won't reach here
                }
                finally
                {
                    Debug.Log("test try step 8");
                }
            }
            catch
            {
                Debug.Log("test try step 9");
            }
        }
        void CrashHere()
        {
            GameObject go = null;
            go.GetComponent<HotUpdateBehaviour>();//null object,will be error here
            Debug.Log("won't reach here");
        }

        void ThrowExcept()
        {
            Debug.Log("test try ThrowExcept");
            throw new Exception("test throw except");//test throw Exception
        }
    }
}