/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using UnityEngine;

namespace CSharpLike
{
    /// <summary>
    /// Example test C# function in hot update script.
    /// </summary>
    public partial class SampleCSharp : LikeBehaviour
    {
        /// <summary>
        /// test modifier for params of function,
        /// include 'ref' 'out' 'in' 'params' keyword.
        /// </summary>
        void TestModifier()
        {
            Debug.LogError("Test Modifier:");
            //test call hot update function which param with ref/out/in modifier
            int v1 = 0;
            int v2;
            Vector2 v3 = new Vector2();
            Vector2 v4;
            int v5 = 5;
            TestRefOutIn(ref v1, out v2, ref v3, out v4, v5);
            //output v1=1,v2=16,v3=(1.0, 16.0),v4=(16.0, 1.0),v5=5
            Debug.Log("TestModifier:TestRefOutIn:v1=" + v1 + ",v2=" + v2 + ",v3=" + v3 + ",v4=" + v4 + ",v5=" + v5);

            //test call hot update static function which param with ref/out/in modifier
            v3 = new Vector2(2, 10);
            v5 = 100;
            TestRefOutInStatic(ref v1, out v2, ref v3, out v4, v5);
            //output v1=1,v2=16,v3=(2.0, 112.0),v4=(16.0, 1.0),v5=100
            Debug.Log("TestModifier:TestRefOutInStatic:v1=" + v1 + ",v2=" + v2 + ",v3=" + v3 + ",v4=" + v4 + ",v5=" + v5);

            //test call hot update function which param with params modifier
            Debug.Log("TestModifier:TestParams:" + TestParam("param1"));//output param1:
            Debug.Log("TestModifier:TestParams:" + TestParam("param2", 1));//output param2:1,
            Debug.Log("TestModifier:TestParams:" + TestParam("param3", 0, "abc"));//output param3:0,abc,
            Debug.Log("TestModifier:TestParams:" + TestParam("param4", 3, "cba", 'x'));//output param4:3,cba,x,

            //test call not hot update function which param with ref/out/in modifier
            ExampleNotHotUpdateScript example = new ExampleNotHotUpdateScript();
            string str1 = "Sunday";
            string str2 = "Saturday";
            v2 = 1;
            example.TestRefOutIn(str1, ref str2, out v1, v2);
            Debug.Log("TestModifier:(not hot update)TestRefOutIn:str2=" + str2 + ",v1=" + v1);//output str2=Sunday test,v1=11

            //test call not hot update static function which param with ref/out/in modifier
            string str3 = "Monday";
            ExampleNotHotUpdateScript.TestRefOutInStatic("abc", ref str3, out v1, 123);
            Debug.Log("TestModifier:(not hot update)TestRefOutInStatic:str2=" + str2 + ",v1=" + v1);//output str2=Sunday test,v1=137

            //test call not hot update function which param with params modifier
            Debug.Log("TestModifier:(not hot update)TestParams:" + example.TestParam());//output :
            Debug.Log("TestModifier:(not hot update)TestParams:" + example.TestParam(10));//output :10,
            Debug.Log("TestModifier:(not hot update)TestParams:" + example.TestParam(1, "xyz"));//output :1,xyz,
            Debug.Log("TestModifier:(not hot update)TestParams:" + example.TestParam('y', "cba", 123));//output :y,cba,123,
        }
        void TestRefOutIn(ref int i, out int j, ref Vector2 k, out Vector2 l, in int m)
        {
            i += 1;
            j = 10 + i + m;
            k.x = i;
            k.y = j;
            l = new Vector2(j, i);
        }
        static void TestRefOutInStatic(ref int i, out int j, ref Vector2 k, out Vector2 l, in int m)
        {
            i += 1;
            j = 10 + i + m;
            k.x = i;
            k.y = j;
            l = new Vector2(j, i);
        }
        string TestParam(string strValue, params object[] objs)
        {
            string str = strValue + ":";
            foreach (var obj in objs)
                str += obj + ",";
            return str;
        }
    }
}